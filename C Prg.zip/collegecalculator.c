#include<stdio.h>
void main()
{
    float r,t,b,s,sp,total;
    printf("Enter your tution fees:");
    scanf("%f",&t);
    printf("\nEnter your hostel rent(If no rent enter 0):");
    scanf("%f",&r);
    printf("\nEnter the price of your books(If no books were bought enter 0):)");
    scanf("%f",&b);
    printf("\n Enter scholarship amount(If no scholarship or if in percentage enter 0):");
    scanf("%f",&s);
    printf("\nEnter scholarship percentage(If no scholarship percent enter 0):");
    scanf("%f",&sp);
    total=t+r+b-s-t+(t*sp/100);
    printf("\nTotal Amount need to be spent:$ %0.2f",total);
}