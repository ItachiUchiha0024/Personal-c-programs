#include<stdio.h>
void main()
{
    int a,b,A,B;
    printf("\nN1=");
    scanf("%d",&a);
    printf("\nN2=");
    scanf("%d",&b);
    A=a;
    B=b;
    printf("\nbefore swapping:");
    printf("\nN1=%d",a);
    printf("\nN2=%d",b);
    printf("\nAfter swapping:");
    printf("\nN1=%d",B);
    printf("\nN2=%d",A);
}