#include<stdio.h>
void main()
{
    int a,r,b,c;
    printf("Enter the number :");
    scanf("%d",&a);
    r=a%15;
    b=a/3;
    c=a/5;
    if(r==0)
    {printf("The number is divisible by 3 and 5");
     printf("\n%d/3=%d",a,b);
     printf("\n%d/5=%d",a,c);}
     else
    {printf("/nThe number is not divisible by 3 and 5");}

}
