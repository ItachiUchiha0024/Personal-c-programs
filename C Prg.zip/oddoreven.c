#include<stdio.h>
void main()
    {
        int a,r;
        printf("\nEnter the number");
        scanf("%d",&a);
        r=a%2;
        if(r==0)
        {printf("\nIt is an even number");}
        else
        {printf("\nIt is an odd number");}


    }
