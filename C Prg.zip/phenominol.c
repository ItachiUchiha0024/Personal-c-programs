#include<stdio.h>
int main ()
{
int sid;
char name [40]; 
printf("Enter Student ID");
scanf("%d",&sid);
printf("\nEnter Student Name");
scanf("%s",&name);
printf("\nStudent ID=%d",&sid);
printf("\nStudent Name=%s",&name);
}
