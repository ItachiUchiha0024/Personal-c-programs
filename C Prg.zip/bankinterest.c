#include<stdio.h>
void main()
{ float i,a,b,c;
printf("\nType your initial investment");
scanf("%f",&i);
a=i+i*5/100;
b=a+a*5/100;
c=b+b*5/100;
printf("\nAccount balance after 1 year :$%0.2f",a);
printf("\nAccount balance after 2 years:$%0.2f",b);
printf("\nAccount balance after 3 years:$%0.2f",c);
}