#include<stdio.h>
int main()
{
    int a,i,j;
    printf("Enter the number of rows: ");
    scanf("%d",&a);
    for (i=1;i<=a;i++)
    {
        for (j=i;j<=a;j++)
        {
            printf("%d",i);
        }
        printf("\n");
    }
    return 0;
}