#include<stdio.h>
void main()
{
    float a,b,c;
    printf("The value of a=");
    scanf("%f",&a);
    b=a*a;
    c=b*a;
    printf("The sq of a =%0.0f and the cube of a=%0.0f",b,c);
}