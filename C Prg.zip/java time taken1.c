#include <stdio.h>
void main()
{
    float D,C,De,T,Designing,Coding,Debugging,Testing;
     
    printf("\nEnter the number of minutes spent on each of the following project");
    printf("\nDesigning:");
    scanf("%d",&D);
    printf("\nCoding:");
    scanf("%d",&C);
    printf("\nDebugging:");
    scanf("%d",&De);
    printf("\nTesting:");
    scanf("%d",&T);
    Designing=(D/(D+C+De+T))*100;
    Coding=(C/(D+S+De+T)*100);
    Debugging=(De/(D+C+De+T)*100);
    Testing=(T/(D+C+De+T)*100);
    printf("\nTask %Time");
    printf("\nDesigning %0.2f",Debugging);
    printf("\nCoding %0.2f",Coding);
    printf("\nDebugging %0.2f",Debugging);
    printf("\nTesting %0.2f",Testing);
}

}