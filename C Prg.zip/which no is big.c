#include<stdio.h>
void main()
{
    float a,b;
    printf("\nEnter first no.");
    scanf("%f",&a);
    printf("\n Enter second no.");
    scanf("%f",&b);
    if(a>b)
    {print("Largest no. is %f",a);}
    else
    {printf(Largest no. is %f,b);}
}