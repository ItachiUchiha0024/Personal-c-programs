#include<stdio.h>
void main()
    {   char name[40],status;
        printf("\n Do you want to give offline examination or online examination?");
        printf("\nEnter your name:");
        scanf("%s",&name);
        fflush(stdin);
        printf("\nIf yes type Y or if no type N\t\t:");
        scanf("%c",&status);
        if (status=='Y'||status=='y')
        {printf("Thank you for your answer");}
        else
         {printf("invalid input");}

    }
