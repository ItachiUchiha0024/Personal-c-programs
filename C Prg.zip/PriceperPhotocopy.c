#include<stdio.h>
void main()
{
float a,total;
printf("\n Enter the number of copies to be printed:");
scanf ("%f",&a);
if(a>=0 && a<=99)
{printf("Price per copy is :$0.30");
total=a*0.30;}
else if(a>=100 && a<=499)
{printf("Price per copy is :$0.28");
total=a*0.28;}
else if(a>=500 && a<=749)
{printf("Price per copy is :$0.27");
total=a*0.27;}
else if(a>=750 && a<=1000)
{printf("Price per copy is :$0.26");
total=a*0.26;}
else if(a>=1000)
{printf("Price per copy is :$0.25");
total=a*0.25;}
printf("\nTotal cost is: $%0.2f",total);
}