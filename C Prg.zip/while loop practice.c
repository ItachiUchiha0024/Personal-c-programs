#include<stdio.h>
void main ()
{
    int a,b,c;
    printf("Enter the first number");
    scanf("%d\n",&a);
    scanf("%d\n",&b);
    scanf("%d\n",&c);
    if (a>b&&a>c)
    {
        printf("The largest number is %d",a);
    }
    if (b>a&&b>c)
    {
        printf("The largest number is %d",b);
    }
    if (c>a&&c>b)
    {
        printf("The largest number is %d",c);
    }
}
