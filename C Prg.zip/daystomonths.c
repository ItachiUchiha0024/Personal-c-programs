#include<stdio.h>
void main()
{
    int d,w,m,mo;
    printf("Enter the number of days:");
    scanf("%d",&d);
    w=d/7;
    m=d/30;
    mo=d/31;
    printf("\nthe number of weeks are %d",w);
    printf("\nThe number of months if month has 30 days are %d",m);
    printf("\nThe number of months if month has 31 days are %d",mo);
}