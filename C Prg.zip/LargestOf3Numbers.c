#include<stdio.h>
void main()
{
    float a,b,c;
    printf("Enter the first number :");
    scanf("%f",&a);
    printf("\nEnter the second number :");
    scanf("%f",&b);
    printf("\nEnter the third number :");
    scanf("%f",&c);
    if (a<=b&&a<=c)
    {printf("First number is the largest number");}
    else if(b<=c&&b<=a)
    {printf("Second number is the largest number");}
    else if(c<=a&&c<=b)
    {printf("Third number is the Largest number");}
}