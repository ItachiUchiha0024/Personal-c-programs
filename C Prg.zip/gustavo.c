#include<stdio.h>
void main ()
{
    float a,b,c;
    printf("Radius of cylinder:");
    scanf("%f",&a);
    printf("Enter the height of the cylinder:");
    scanf("%f",&b);
    c=2*(3.14)*a*a*b;
    printf("The voloume of cylinder is: %0.2f cube units",c);
}
