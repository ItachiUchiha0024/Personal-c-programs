#include<stdio.h>
int main()
{   char a[25];
    float rn,math,che,phy,total,avg;
    printf("Enter the name of the student:\n");
    scanf("%s",&a);
    printf("Enter roll no of the student:\n");
    scanf("%f",&rn);
    printf("Enter Math marks:\n");
    scanf("%f",&math);
    printf("Enter Chemistry marks:\n");
    scanf("%f",&phy);
    printf("Enter English marks:\n");
    scanf("%f",&che);
    total=phy+che+math;
    avg=total/3;
    printf("Total marks is :%0.0f\n",total);
    printf("Average marks of the student is :%0.2f\n",avg);
    return 0;
}