#include<stdio.h>
void main()
{
    float a,b,c;
    printf("The value of a=");
    scanf("%f",&a);
    printf("The value of b=");
    scanf("%f",&b);
    c=(a+b)*(a+b);
    printf("The answer is %0.0f",c);

}