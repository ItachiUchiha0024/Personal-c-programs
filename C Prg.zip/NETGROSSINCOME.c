#include<stdio.h>
void main()
{
    float BS,DA,HRA,PF,IT,Gross,Net,MA;
 char name[50];
 printf("Employ Name:");
 scanf("%s",&name);
 printf("Basic Salary:");
 scanf("\n%f",&BS);
 printf("HRA :");
 scanf("%f",&HRA);
 printf("DA :");
 scanf("%f",&DA);
 printf("PF:");
 scanf("%f",&PF);
 printf("IT :");
 scanf("%f",&IT);
 printf("MA :");
 scanf("%f",&MA);
 Gross=BS+(BS*HRA/100)+(BS*DA/100)+MA;
 Net=Gross-(BS*PF/100+BS*IT/100);
 printf("Empoloyee Name \t\tBasic Salary\t\tHRA\t\tDA\t\tPF\t\tIT\t\tGross\t\tNet Salary");
 printf("\n%s\t\t\t%0.0f\t\t\t%0.0f\t\t%0.0f\t\t%0.0f\t\t%0.0f\t\t%0.0f\t\t%0.0f",name,BS,HRA,DA,PF,IT,Gross,Net);
 }
 
 


