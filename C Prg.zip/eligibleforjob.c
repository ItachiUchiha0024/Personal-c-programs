#include<stdio.h>
void main()
{
    int a,b,c,d;
    printf("Enter the age of applicant:");
    scanf("%d",&a);
    if (a>=18&&a<=50)
    {
        printf("The applicant is eligible");
    }
    else 
    {
        printf("The applicant is not eligible");
    }
}