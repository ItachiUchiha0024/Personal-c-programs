#include<stdio.h>
void main()
{
    char ch;
    printf("Enter any alphabet:");
    scanf("%c",&ch);
    if(ch>=97&&ch<=122)
    {printf("It is lowercase");}
    else
    {printf("It is not lowercase");}
}