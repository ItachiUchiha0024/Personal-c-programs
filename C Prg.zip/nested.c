#include<stdio.h>
void main()
{
    char name;
    int a;
    printf("Enter your age :");
    scanf("%d",&a);
    fflush(stdin);
    printf("Are you an Indian Y/N :");
    scanf("%c",&name);
    if (a>=18)
    {
         if (name=='Y' || name=='y')
         {
            printf("You can vote");
         }
        else
        {
            printf("Sorry you are not eligible to vote,due to not indian");
        }
    }
     else {printf("Sorry you are under age");}

}