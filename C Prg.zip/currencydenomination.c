#include <stdio.h>
void main()
{
	int r,a,b,c,d;
	printf("enter the total amount:");
	scanf("%d",&r);
	a=r/500;
	b=r%500/200;
	c=r%500%200/100;
	d=r%500%200%100;
	printf("500rs notes =%d\n" ,a);
	printf("200rs notes = %d\n",b);
	printf("100rs notes = %d\n",c);
	printf("1rs notes = %d\n",d);
}