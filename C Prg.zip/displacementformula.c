#include<stdio.h>
void main()
{
    clrscr();
    
}