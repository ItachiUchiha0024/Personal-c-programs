#include<stdio.h>

int main() {
  int arr[5];
  for (int i = 0; i < 5; i++) {
    printf("Enter element %d: ", i+1);
    scanf("%d", &arr[i]);
  }

  printf("Elements in array: ");
  for (int i = 0; i < 5; i++) {
    printf("%d ", arr[i]);
  }
  
  return 0;
}
int main() {
  int source[5] = {1, 2, 3, 4, 5};
  int dest[5];{
    dest[i] = source[i];}
  
  printf("Elements in destination array: ");
  for (int i = 0; i < 5; i++)
  {
    printf("%d ", dest[i]);
  }
  
  return 0;
}