#include<stdio.h>
void main()
{
    char name[40],status;
    int g;
    printf("Enter your name");
    scanf("%s",&name);
    printf("Enter your age");
    scanf("%d",&g);
    if(g>=18)
    {printf("Congratulations! %s You can vote",name);}
    else
    {printf("\nGo home %s have Bournvita",name);}
  }