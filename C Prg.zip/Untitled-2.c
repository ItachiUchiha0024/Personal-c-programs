#include<stdio.h>
void main()
{
    float h,a;
    float p;
    char name[40];
    printf("\nEnter your name :");
    scanf("%s",&name);
    printf("\nNo. of classes held :");
    scanf("%f",&h);
    printf("\nNo. of classes attended");
    scanf("%f",&a);
    p=(a*100)/h;
    printf("\nYour attendence :%f",p);
    if(p>=75)
    {printf("%s, you are eligible to give examination",name);}
    else
    {printf("%s, you are not eligible to give examination",name);}
}