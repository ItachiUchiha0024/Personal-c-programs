#include <stdio.h>
void main()
{    
    float t,H;
    printf("\nEnter the time less than 4.5 seconds");
    scanf("\n%f",&t);
    H=100-(4.9*(t*t));
    printf("\n The height of the object=%0.2f meters",H);
    
    
    
    
    
    
    
    
    }