#include<stdio.h>
int main()
{   
    float a,cir,area;
    printf("Enter the radius of circle:");
    scanf("%f",&a);
    cir=2*(22/7)*a;
    area=(22/7)*a*a;
    printf("The circumference of circle is:%0.2f",cir);
    printf("\nThe area of circle :%0.2f",area);
}