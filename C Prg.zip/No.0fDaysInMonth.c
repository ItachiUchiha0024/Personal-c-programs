#include<stdio.h>
void main()
{
    int a;
    printf("Enter the month number from 1 to 12 :");
    scanf("%d",&a);
    if (a==1 || a==3 || a==5|| a==7 || a==8 || a==10 || a==12)
    {printf("\nThe number of days are 31");}
    else if(a==4 || a==6 || a==9 || a==11)
    {printf("\nThe number of days are 30");}
    else if(a==2)
    {printf("\nThe number of days are 28");}
}