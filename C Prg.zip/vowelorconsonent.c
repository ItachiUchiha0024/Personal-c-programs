#include<stdio.h>
void main()
{
    char status;
    printf("Enter any small alphabet:");
    scanf("%c",&status);
    if(status=='a'||status=='e'||status=='i'||status=='o'||status=='u')
    {printf("It is a vowel");}
    else
    {printf("It is a consonent");}

}