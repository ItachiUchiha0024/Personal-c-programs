#include<stdio.h>
void main()
{
    float a,b,c;
    printf("Enter the first number :");
    scanf("%f",&a);
    printf("Enter the second number :");
    scanf("%f",&b);
    printf("Enter the third number :");
    scanf("%f",&c);
    if (a>b)
    {
        if(a>c)
        {
            printf("First number is the largest number");
        }
    }
    if (b>c)
    {if(b>a)
    {
        printf("Second number is the largest number");
    }
    }
    if(c>a)
    {if(c>b)
    {
        printf("Third number is the largest number");
        }
        }
}