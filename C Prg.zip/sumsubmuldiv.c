#include<stdio.h>
int main()
{   
    int a,b,sum,sub,mul,div;
    printf("Enter a number:");
    scanf("%d",&a);
    printf("Enter the second number");
    scanf("%d",&b);
    sum=a+b;
    sub=a-b;
    mul=a*b;
    div=a/b;
    printf("\nSum=%d",sum);
    printf("\nSubtration=%d",sub);
    printf("\nMultiply=%d",mul);
    printf("\nDivide=%d",div);
}