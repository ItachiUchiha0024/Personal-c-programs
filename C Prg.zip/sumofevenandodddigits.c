#include<stdio.h>
void main()
{
    int a,b,c,d,e,f,g,h,i,j,k;
    scanf("%d",&a);
    b=a/1000;
    c=a%1000;
    d=c/100;
    e=d%100;
    f=e/10;
    g=f%10;
    if( b%2==0&&d%2==0&&f%2==0&&g%2==0)
    {
        h=b+d+f+g;
        printf("%d",h);
    }
    else if(b%2!=0&&d%2!=0&&f&2!=0&&g%2!=0)
    {
        i=b+d+f+g;
        printf("%d",i);
    }
}