#include<stdio.h>
void main()
{
    float a,b,c,d,sum;
    printf("Hello World");
    scanf("%f",&a);
    scanf("%f",&b);
    scanf("%f",&c);
    scanf("%f",&d);
    printf("Sum is equal to:");
    sum=a+b+c+d;
    printf("%0.0f",sum);

}