#include<stdio.h>
void main()
{
    float a,b,c,d,sum;
    printf("Hello World");
    scanf("%f",&a);
    scanf("%f",&b);
    scanf("%f",&c);
    scanf("%f",&d);
    sum=a+b+c+d;
    printf("%f",sum);
}