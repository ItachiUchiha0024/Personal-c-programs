#include<stdio.h>
void main()
{
    char color;
    printf("Write intial of the color name(in capital):");
    scanf("%C",&color);
    if(color=='Red'||color=='Green'||color=='Blue')
    {printf("It is a primary color");}
    else
    {printf("It is a secondry color");}
}