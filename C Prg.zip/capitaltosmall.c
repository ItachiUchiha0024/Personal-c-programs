#include<stdio.h>
void main()
{
    char a;
    printf("Enter any alphabet:");
    scanf("%c",&a);
    
    if(a>=97&&a<=122)
    {
        a=a-32;
        printf("its capital is :%c",a);
    }
    else if(a>=65&&a<=96)
    {
        a=a+32;
        printf("It's small is  :%c",a);
    }
}