#include<stdio.h>
int main(void)
{
    int a,b,codd=0,ceven=0,seven=0,sodd=0; 
    scanf("%d",&a);
    while(a!=0)
    {
        b=a%10;
        if(b%2==0)
        {
            ceven+=1;
            seven+=b;
        }
        else{
            codd+=1;
            sodd+=b;
        }
        a=a/10;
    }
    if(ceven>codd)
{
    printf("%d",seven);
}
else{
    printf("%d",sodd);
}
}