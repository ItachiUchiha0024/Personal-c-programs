#include<stdio.h>
void main()
{
    int a;
    printf("Enter the integer:");
    scanf("%d",&a);
    if (a>=1)
    {
        printf("The number is positive");
    }
    else if (a==0)
    {
        printf("The number is zero");
    }
    else if (a<=-1)
    {
        printf("The number is negetive");
    }
}    