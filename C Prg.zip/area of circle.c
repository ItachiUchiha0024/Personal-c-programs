#include <stdio.h>
 void main()
    { float r,a;
      printf("\nRadius of the circle");
      scanf("%f",&r);
      a=3.14*(r*r);
      printf("\nArea of the circle=%0.2f",a);
      
    }
