#include <stdio.h>
void main()
{
    int b,f,s,Total,Final,t,Return;
    printf("\nEnter the number of burgers");
    scanf("\n%d",&b);
    printf("\nEnter the number of fries");
    scanf("\n%d",&f);
    printf("\nEnter the number of sodas");
    scanf("\n%d",&s);
    Total=(1.69*b)+(1.09*f)+(0.99*s);
    printf("\nTotal before tax:  $%d",Total);
    Final=(1.69*b)+(1.09*f)+(0.99*s)+0.90;
    printf("\nFinal total:  $%d",Final);
    printf("\nEnter Amount Tendered");
    scanf("\n%d",&t);
    Return=t-Final;
    printf("\nChange:  $%d",Return);
}