#include<stdio.h>
void main()
{
    float r,w,s,l,avg;
    printf("Enter marks in Reading");
    scanf("%f",&r);
    printf("Enter marks in Writing");
    scanf("%f",&w);
    printf("Enter marks in Speaking");
    scanf("%f",&s);
    printf("Enter marks in Listerning");
    scanf("%f",&l);
    avg=(r+s+w+l)/4;
    printf("Your Bands:%0.2f",avg);    
}