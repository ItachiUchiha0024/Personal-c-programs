#include<stdio.h>
void main()
{float a;

    printf("Enter the percentage:");
    scanf("%f",&a);
    if(a>=900 && a<=100)
    {printf("The corrosponding letter grade is :A");}
    else if (a>=70 && a<=89)
    {printf("The corrosponding letter grade is :B");}
    else if (a>=60 && a<=69)
    {printf("The corrosponding letter grade is :C");}
    else if (a>=50 && a<=59)
    {printf("The corrosponding letter grade is :D");}
}