#include<stdio.h>
void main()
{
    float Faren,Celsi;
    printf("Type the temperature in F:");
    scanf("%f",&Faren);
    Celsi=0.56*(Faren-32);
    printf("Temperature in celsius:%0.2f",Celsi);
}