#include<stdio.h>
void main()
{   char name[40];
    int x;
    float a,b,c,d,e,f,netcharge1,netcharge2,netcharge3,netcharge4,netcharge5;
    printf("\nEnter the name of user:");
    gets(name);
    printf("Enter the user id:");
    scanf("%d",&x);
    printf("\nEnter the number of units:");
    scanf("%f",&a);
    if (a>=101 && a<=200)
        {
            b=a*(1.20);
            netcharge1=b+240;
            printf("\nThe amount will be charged at rate of 1.20 and total amount is: Rs%0.0f",b);
            printf("\nThe net charge after adding surcharge of rs240 will be: Rs%0.0f",netcharge1);
        }
    if (a>=201 && a<=400)
        {
            c=a*(1.50);
            netcharge2=c+240;
            printf("\nThe amount will be charged at rate of of 1.50 and total amount is: Rs%0.0f",c);
            printf("\nThe net charge after adding surcharge of rs240 will be: Rs%0.0f",netcharge2);
        }
    if (a>=401 && a<=600)
        {
            d=a*(1.80);
            netcharge3=d+240;
            printf("\nThe amount will be charged at rate of of 1.80 and total amount is: Rs%0.0f",d);
            printf("\nThe net charge after adding surcharge of rs240 will be: Rs%0.0f",netcharge3);
        } 
    if (a>=601 && a<=800)
        {
            e=a*(2.00);
            netcharge4=e+240;
            printf("\nThe amount will be charged at rate of 2.00 and total amount is: Rs%0.0f",e);
            printf("\nThe net charge after adding surcharge of Rs240 will be: Rs%0.0f",netcharge4);
        `}
    if (a>=801 && a<=1000)
        
        {
            f=a*(2.20);
            netcharge5=f+240;
            printf("\nThe amount will be charged at rate of 2.20 and total amount is: Rs%0.0f",f);
            printf("\nThe net amount after adding surcharge of Rs240 will be: Rs%0.0f",netcharge5);
        }
}