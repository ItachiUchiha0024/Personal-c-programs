#include <stdio.h>
void main()
{
    int t,H,M;  
    printf("\n Enter the time in minutes");
    scanf("%d"&t,&H,&M);
    H=t/60;
    M=t%60;
    printf("\nThe time is :%d:%d",H,M);


}