#include<stdio.h>
#include<math.h>
void main()
{
    float a,b;
    printf("Enter a number: ");
    scanf("%f",&a);
    b=sqrt(a);
    printf("The squareroot of %0.0f= %0.2f",a,b);
}