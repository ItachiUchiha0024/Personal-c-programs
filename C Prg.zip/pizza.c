#include<stdio.h>
void main()
{ 
int d,Cost;
printf("\nEnter the diameter of the pizza in inches:");
scanf("%d",&d);
Cost=0.75+1+(0.05*d*d);
printf("\nThe cost of making the pizza=$%d",Cost);
}