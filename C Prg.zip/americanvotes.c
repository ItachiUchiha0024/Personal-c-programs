#include<stdio.h>
void main()
{
    char d='%';
    float t,pa,pm,ta,tm;
    int any,mny,anj,mnj,ac,mct;
    printf("\nNo. of people voted for Awbrey in New York:");
    scanf("%d",&any);
    printf("\nNo. of people voted for Martinez in New York:");
    scanf("%d",&mny);
    printf("\nNo. of people voted for Awbrey in New Jersey:");
    scanf("%d",&anj);
    printf("\nNo. of people voted for Martinez in New Jersey:");
    scanf("%d",&mnj);
    printf("\nNo. of people voted for Awbery in Connecticut:");
    scanf("%d",&ac);
    printf("\nNo. of people voted for Martinez in Connecticut:");
    scanf("%d",&mct);
    t=any+mny+anj+mnj+ac+mct;
    ta=any+anj+ac;
    tm=mny+mnj+mct;
    pa=100*ta/t;
    pm=100*tm/t;
   printf("Candidate\t\tVotes\t\tpercentage");
   printf("\nAwbrey\t\t\t%0.0f\t\t%0.2f%c",ta,pa,d);
   printf("\nMartinez\t\t%0.0f\t\t%0.2f%c",tm,pm,d);
}